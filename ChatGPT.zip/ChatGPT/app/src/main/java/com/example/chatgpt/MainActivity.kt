package com.example.chatgpt

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val question = findViewById<TextInputEditText>(R.id.question)
        val button = findViewById<Button>(R.id.button)
        val answer = findViewById<TextView>(R.id.answer)

        button.setOnClickListener(){
            val q = question.getText().toString()
            getResponse(q){response ->
                runOnUiThread{
                    answer.text = response
                }
            }
        }
    }

    fun getResponse(q: String, callback: (String) -> Unit){
        val api = "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"
        val url = "https://api.openai.com/v1/completions"

        val requestBody = """
            {
            "model":"text-davinci-003",
            "prompt":"$q",
            "max_tokens":7,
            "temperature":0
            }
            """.trimIndent()

        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .addHeader("Authorization", "Bearer $api")
            .post(requestBody.toRequestBody("application/json".toMediaTypeOrNull()))
            .build()

        client.newCall(request).enqueue(object: Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("error","API Failed",e)
            }

            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                if (body != null){
                    Log.v("data",body)
                }else{
                    Log.v("data","empty")
                }
                val jsonObject = JSONObject(body)
                val jsonArray: JSONArray = jsonObject.getJSONArray("choices")
                val text = jsonArray.getJSONObject(0).getString("text")
                callback(text)
            }
        })
        }
}
