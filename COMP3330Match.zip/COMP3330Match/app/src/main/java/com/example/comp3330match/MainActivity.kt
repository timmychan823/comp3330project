package com.example.comp3330match

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {
    private var btn_rest: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_rest = findViewById<Button>(R.id.btn_rest)
        setlistener(btn_rest!!)


    }
// Set a click listener for button to press the restaurant name to next activity after choosing the restaurant + switch activity
    fun setlistener(b: Button){
        b.setOnClickListener(){
            val rname = b.getText().toString()
            switchactivity(rname)
        }
    }

    fun switchactivity(rname: String){
        val intent = Intent(this, TimeslotActivity::class.java)
        intent.putExtra("rname",rname)
        startActivity(intent)
    }
}